let cars = [
    "Bmw" , "Ford" , "Toyota"
]



let model = [
    ["x6", "m5", "x5" ],
    ["Mustang" , "Fusion"],
    ["Pirus", "Camry", "Carolla"]
]

// console.log(model[1][0]);


let carsS = document.getElementsByTagName("select")[0];
let modelS = document.getElementsByTagName("select")[1];


onload = function(){
    let option = ` <option selected disabled>Masin sec</option>`;
    for(let i = 0; i<cars.length; i++){
        option += ` <option value="${i}">${cars[i]}</option>`
    }
    carsS.innerHTML = option;
}

carsS.onchange = function(){
    let option = ` <option selected disabled>Marka sec</option>`;
    let take = carsS.value;
    for(let i = 0; i<model[take].length; i++){
option +=  ` <option value="${i}" > ${model[take][i]} </option>`;
    }
modelS.innerHTML = option;
}
modelS.onchange = function(){
    let x = carsS.value;
    let y = modelS.value;
    document.getElementById("show").innerHTML = `Siz ${cars[x]} ${model[x][y]} - modelini secdiz`;
}
